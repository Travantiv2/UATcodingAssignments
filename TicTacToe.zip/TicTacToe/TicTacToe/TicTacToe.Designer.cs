﻿
namespace TicTacToe
{
    partial class TicTacToe
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            lblTitle = new Label();
            panel2 = new Panel();
            btn22 = new Button();
            btn12 = new Button();
            btn21 = new Button();
            btn20 = new Button();
            btn11 = new Button();
            btn10 = new Button();
            btn02 = new Button();
            btn01 = new Button();
            btn00 = new Button();
            panel3 = new Panel();
            lblCpuWins = new Label();
            lblPlayerWins = new Label();
            panel4 = new Panel();
            btnExit = new Button();
            btnClearBoard = new Button();
            btnReset = new Button();
            lblTies = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveBorder;
            panel1.Controls.Add(lblTitle);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1204, 67);
            panel1.TabIndex = 0;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Comic Sans MS", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTitle.Location = new Point(492, 9);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(221, 51);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Tic Tac Toe";
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblTitle.Click += lblTitle_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(224, 224, 224);
            panel2.Controls.Add(btn22);
            panel2.Controls.Add(btn12);
            panel2.Controls.Add(btn21);
            panel2.Controls.Add(btn20);
            panel2.Controls.Add(btn11);
            panel2.Controls.Add(btn10);
            panel2.Controls.Add(btn02);
            panel2.Controls.Add(btn01);
            panel2.Controls.Add(btn00);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 67);
            panel2.Name = "panel2";
            panel2.Size = new Size(617, 534);
            panel2.TabIndex = 1;
            // 
            // btn22
            // 
            btn22.Location = new Point(415, 358);
            btn22.Name = "btn22";
            btn22.Size = new Size(196, 170);
            btn22.TabIndex = 6;
            btn22.UseVisualStyleBackColor = true;
            btn22.Click += btn22_Click;
            // 
            // btn12
            // 
            btn12.Location = new Point(415, 182);
            btn12.Name = "btn12";
            btn12.Size = new Size(196, 170);
            btn12.TabIndex = 5;
            btn12.UseVisualStyleBackColor = true;
            btn12.Click += btn12_Click;
            // 
            // btn21
            // 
            btn21.Location = new Point(214, 358);
            btn21.Name = "btn21";
            btn21.Size = new Size(196, 170);
            btn21.TabIndex = 5;
            btn21.UseVisualStyleBackColor = true;
            btn21.Click += btn21_Click;
            // 
            // btn20
            // 
            btn20.Location = new Point(12, 358);
            btn20.Name = "btn20";
            btn20.Size = new Size(196, 170);
            btn20.TabIndex = 4;
            btn20.UseVisualStyleBackColor = true;
            btn20.Click += btn20_Click;
            // 
            // btn11
            // 
            btn11.Location = new Point(214, 182);
            btn11.Name = "btn11";
            btn11.Size = new Size(196, 170);
            btn11.TabIndex = 4;
            btn11.UseVisualStyleBackColor = true;
            btn11.Click += btn11_Click;
            // 
            // btn10
            // 
            btn10.Location = new Point(12, 182);
            btn10.Name = "btn10";
            btn10.Size = new Size(196, 170);
            btn10.TabIndex = 3;
            btn10.UseVisualStyleBackColor = true;
            btn10.Click += btn10_Click;
            // 
            // btn02
            // 
            btn02.Location = new Point(415, 6);
            btn02.Name = "btn02";
            btn02.Size = new Size(196, 170);
            btn02.TabIndex = 2;
            btn02.UseVisualStyleBackColor = true;
            btn02.Click += btn02_Click;
            // 
            // btn01
            // 
            btn01.Location = new Point(214, 6);
            btn01.Name = "btn01";
            btn01.Size = new Size(196, 170);
            btn01.TabIndex = 1;
            btn01.UseVisualStyleBackColor = true;
            btn01.Click += btn01_Click;
            // 
            // btn00
            // 
            btn00.Location = new Point(12, 6);
            btn00.Name = "btn00";
            btn00.Size = new Size(196, 170);
            btn00.TabIndex = 0;
            btn00.UseVisualStyleBackColor = true;
            btn00.Click += Btn00_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(224, 224, 224);
            panel3.Controls.Add(lblTies);
            panel3.Controls.Add(lblCpuWins);
            panel3.Controls.Add(lblPlayerWins);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(617, 67);
            panel3.Name = "panel3";
            panel3.Size = new Size(587, 331);
            panel3.TabIndex = 2;
            // 
            // lblCpuWins
            // 
            lblCpuWins.AutoSize = true;
            lblCpuWins.Font = new Font("Comic Sans MS", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCpuWins.Location = new Point(6, 136);
            lblCpuWins.Name = "lblCpuWins";
            lblCpuWins.Size = new Size(226, 56);
            lblCpuWins.TabIndex = 1;
            lblCpuWins.Text = "CPU Wins: ";
            lblCpuWins.Click += lblCpuWins_Click;
            // 
            // lblPlayerWins
            // 
            lblPlayerWins.AutoSize = true;
            lblPlayerWins.Font = new Font("Comic Sans MS", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPlayerWins.Location = new Point(6, 6);
            lblPlayerWins.Name = "lblPlayerWins";
            lblPlayerWins.Size = new Size(266, 56);
            lblPlayerWins.TabIndex = 0;
            lblPlayerWins.Text = "Player Wins: ";
            lblPlayerWins.Click += lblPlayerWins_Click;
            // 
            // panel4
            // 
            panel4.Controls.Add(btnExit);
            panel4.Controls.Add(btnClearBoard);
            panel4.Controls.Add(btnReset);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(617, 398);
            panel4.Name = "panel4";
            panel4.Size = new Size(587, 203);
            panel4.TabIndex = 3;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(390, 6);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(185, 191);
            btnExit.TabIndex = 2;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // btnClearBoard
            // 
            btnClearBoard.Location = new Point(197, 6);
            btnClearBoard.Name = "btnClearBoard";
            btnClearBoard.Size = new Size(185, 191);
            btnClearBoard.TabIndex = 1;
            btnClearBoard.Text = "Clear";
            btnClearBoard.UseVisualStyleBackColor = true;
            btnClearBoard.Click += btnClearBoard_Click;
            // 
            // btnReset
            // 
            btnReset.Location = new Point(6, 6);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(185, 191);
            btnReset.TabIndex = 0;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // lblTies
            // 
            lblTies.AutoSize = true;
            lblTies.Font = new Font("Comic Sans MS", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTies.Location = new Point(6, 260);
            lblTies.Name = "lblTies";
            lblTies.Size = new Size(127, 56);
            lblTies.TabIndex = 2;
            lblTies.Text = "Ties: ";
            lblTies.Click += lblTies_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(11F, 24F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1204, 601);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Font = new Font("Comic Sans MS", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "Form1";
            Text = "TicTacToe";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            ResumeLayout(false);
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Button btn02;
        private Button btn01;
        private Button btn00;
        private Button btn22;
        private Button btn12;
        private Button btn21;
        private Button btn20;
        private Button btn11;
        private Button btn10;
        private Panel panel4;
        private Button btnReset;
        private Button btnExit;
        private Button btnClearBoard;
        private Label lblTitle;
        private Label lblPlayerWins;
        private Label lblCpuWins;
        private Label lblTies;
    }
}
